'use strict';

module.exports = require('./_formatLimit')('Minimum');
